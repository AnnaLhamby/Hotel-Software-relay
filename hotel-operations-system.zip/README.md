# Hotel Operations System

A shareable static prototype for a hotel task workflow:

- Guest room iPad request portal
- Front desk audio task capture
- Staff Kanban board
- Task detail page
- Operations control dashboard
- Reporting and analytics

## Deploy

This project has no build step. Upload the folder to any static host.

### Netlify

Drag this folder into Netlify Drop, or connect it as a Git repository. Publish directory: `.`.

### Vercel

Import the folder/repository as a static project. Output directory: `.`.

### GitHub Pages

Push these files to a GitHub repository, then enable Pages with branch `main` and folder `/root`.

## Local Preview

Run:

```sh
python3 -m http.server 8000 --bind 127.0.0.1
```

Then open `http://127.0.0.1:8000`.

Task changes are saved in each browser with `localStorage`. For a real multi-user hotel deployment, replace the local data store with a shared backend such as Supabase, Firebase, or a custom API.
